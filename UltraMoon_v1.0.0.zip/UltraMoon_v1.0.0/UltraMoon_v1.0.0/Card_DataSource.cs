﻿using Card_Model;
using System;
using System.Collections.Generic;

namespace Card_DataSource
{
    public class DataSource
    {
        public static List<Card> LoadCards(string path)
        {
            List<Card> cardList = new List<Card>();

            if (!File.Exists(path))
            {
                Console.WriteLine("Error: cards.txt not found.");
                return cardList;
            }

            string[] lines = File.ReadAllLines(path);

            foreach (string line in lines)
            {
                string[] parts = line.Split(',');

                Card card = new Card
                {
                    Name = parts[0],
                    Type = Enum.Parse<CardType>(parts[1].ToUpper()),
                    Rarity = int.Parse(parts[2]),
                    HP = int.Parse(parts[3]),
                    AttackCode = parts[4],
                    Attack = int.Parse(parts[5]),
                    SpecialMove = parts[6]
                };

                cardList.Add(card);
            }

            return cardList;
        }
    }
}